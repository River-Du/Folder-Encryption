本目录用于测试和学习加密、解密文件夹。

测试条件：
本测试基于 encryption_decryption.bat 的以下配置项：
set TARGETS="private_1" "private_2" "private_3" "private_4"
set "DELETE_SOURCE_AFTER_ENCRYPT=1"
set "DELETE_ARCHIVE_AFTER_DECRYPT=1"
set "SEVENZIP_EXE="

推荐测试方法：
若要验证加密效果，请进入 加密测试 文件夹，阅读readme.txt
若要验证解密效果，请进入 解密测试 文件夹，阅读readme.txt
若要自定义测试，可从 全部测试对象 文件夹中复制对象，进行自定义测试。

自定义测试方法：
将 encryption_decryption.bat 和 7za.exe 放入带解密或待加密文件夹中，
双击运行 bat 脚本，选择解密或加密，输入密码，等待脚本输出结果。
