原始目录组成：
private_1.7z private_2.7z private_4.7z private_2/ private_3/

测试条件：
本测试基于 encryption_decryption.bat 的以下配置项：
set TARGETS="private_1" "private_2" "private_3" "private_4"
set "DELETE_SOURCE_AFTER_ENCRYPT=1"
set "DELETE_ARCHIVE_AFTER_DECRYPT=1"
set "SEVENZIP_EXE="

本目录压缩包解压密码：
private_1、private_2 密码为 1
private_4 密码为 2

测试流程：
将 encryption_decryption.bat 和 7za.exe 放入本目录中，
双击运行 bat 脚本，输入 D 进行解密，输入解压密码 1。

最终应得到结果如下：

【处理结果】
目标       动作  原文件    输出文件    结果   备注
------------------------------------------------------
private_1  解密  删除      生成        成功√  无
private_2  解密  删除      替换        成功√  无
private_3  跳过  无压缩包  已有文件夹  跳过-  未处理
private_4  解密  保留      未生成      失败×  解压失败

结果解读：
private_1 正常解密，输出解密后的文件夹；
private_2 目录中已存在输出文件夹，因此解密后会将旧文件夹替换；
private_3 目录中不存在解密对象，目录中已存在输出文件夹，跳过处理；
private_4 解密时密码错误，因为 private_4 压缩包密码为 2。
