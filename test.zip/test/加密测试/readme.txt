原始目录组成：
private_1/ private_2/ private_2.7z private_3.7z

测试条件：
本测试基于 encryption_decryption.bat 的以下配置项：
set TARGETS="private_1" "private_2" "private_3" "private_4"
set "DELETE_SOURCE_AFTER_ENCRYPT=1"
set "DELETE_ARCHIVE_AFTER_DECRYPT=1"
set "SEVENZIP_EXE="

测试流程：
将 encryption_decryption.bat 和 7za.exe 放入本目录中，
双击运行 bat 脚本，输入 E 进行加密，输入任意压缩密码。

最终应得到结果如下：

【处理结果】
目标       动作  原文件    输出文件    结果   备注
----------------------------------------------------
private_1  加密  删除      生成        成功√  无
private_2  加密  删除      替换        成功√  无
private_3  跳过  无文件夹  已有压缩包  跳过-  未处理
private_4  跳过  无文件夹  无操作      跳过-  未处理

结果解读：
private_1 正常加密，输出加密后的压缩包；
private_2 目录中已存在输出压缩包，因此加密后会将旧压缩包替换；
private_3 目录中不存在加密对象，目录中已存在输出压缩包，跳过处理；
private_4 无加密对象和输出对象，跳过处理。
